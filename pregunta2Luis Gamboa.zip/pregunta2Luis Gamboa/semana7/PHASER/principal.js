var juego = new Phaser.Game(1080, 607, Phaser.CANVAS, 'bloqueJuego');
var fondoJuego;
var flappy;
var boton;
var teclaDerecha, teclaIzquierda, teclaArriba, teclaAbajo;
var musica;

var estadoInicio = {
  preload: function () {
    juego.load.image('fondo', '../IMG/img/aaa.jpeg');
    juego.load.image('btn', '../IMG/img/btn.png');
    juego.load.spritesheet('pajaros', '../IMG/img/maria2.png', 360, 607);
    juego.load.audio('musicaFondo', '../IMG/img/time_is_up.mp3'); // Cargar música
  },

  create: function () {
    fondoJuego = juego.add.sprite(0, 0, 'fondo');

    // Iniciar música
    musica = juego.add.audio('musicaFondo');
    musica.loopFull(0.5); // volumen: 0 = silencio, 1 = máximo

    // Botón
    boton = juego.add.button(juego.width / 2, juego.height / 2, 'btn', this.iniciarJuego, this);
    boton.anchor.setTo(0.5, 0.5);
  },

  iniciarJuego: function () {
    juego.state.start('juego');
  }
};

// --- Estado del juego ---
var estadoJuego = {
  create: function () {
    fondoJuego = juego.add.tileSprite(0, 0, 1080, 607, 'fondo');

    flappy = juego.add.sprite(100, 100, 'pajaros');
    flappy.frame = 1;
    flappy.animations.add('vuelo', [0, 1, 2], 10, true);

    teclaDerecha = juego.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
    teclaIzquierda = juego.input.keyboard.addKey(Phaser.Keyboard.LEFT);
    teclaArriba = juego.input.keyboard.addKey(Phaser.Keyboard.UP);
    teclaAbajo = juego.input.keyboard.addKey(Phaser.Keyboard.DOWN);
  },

  update: function () {
    fondoJuego.tilePosition.x -= 1;
    flappy.animations.play('vuelo');

    if (teclaDerecha.isDown) flappy.x += 3;
    else if (teclaIzquierda.isDown) flappy.x -= 3;

    if (teclaArriba.isDown) flappy.y -= 3;
    else if (teclaAbajo.isDown) flappy.y += 3;
  }
};

// --- Agregamos los estados ---
juego.state.add('inicio', estadoInicio);
juego.state.add('juego', estadoJuego);
juego.state.start('inicio');
